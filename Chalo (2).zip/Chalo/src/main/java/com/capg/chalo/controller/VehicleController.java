package com.capg.chalo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.chalo.entity.Vehicle;
import com.capg.chalo.service.VehicleService;

import jakarta.validation.Valid;

//import com.capg.uber.DTO.VehicleDTO;

@RestController
@RequestMapping("/vehicle")
public class VehicleController {

	@Autowired
	VehicleService vehicleservice;

	@GetMapping("/getall")
	public List<Vehicle> products() {
		return vehicleservice.getAllVehicleDetails();
	}

	@PostMapping("/save")
	public ResponseEntity<Vehicle> save(@Valid @RequestBody Vehicle vehi) {
		System.out.println(vehi);
		return new ResponseEntity<Vehicle>(vehicleservice.addVehicle(vehi), HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{vehicle_id}")
	public String delete(@PathVariable Long vehicle_id) {
		vehicleservice.removeVehicle(vehicle_id);
		return " vehicle with ID " + vehicle_id + " was deleted sucessfully ";
	}

	@PutMapping("/update/{vehicle_id}")
	public ResponseEntity<Vehicle> update(@PathVariable Long vehicle_id, @RequestBody Vehicle vehi) {
		return new ResponseEntity<Vehicle>(vehicleservice.updateVehicle(vehicle_id), HttpStatus.ACCEPTED);
	}

	@DeleteMapping("/deleteAll")
	public String deleteAll() {
		vehicleservice.deleteAll();
		return "ALL PRODUCTS DELETED SUCCESSFULLY";
	}

	@GetMapping("/get/{vehicle_id}")
	public Vehicle vehicleById(@PathVariable Long vehicle_id) {
		return vehicleservice.getVehicleDetails(vehicle_id);
	}

}
