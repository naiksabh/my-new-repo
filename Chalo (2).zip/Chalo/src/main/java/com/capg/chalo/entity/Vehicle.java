package com.capg.chalo.entity;

//import com.capg.uber.DTO.VehicleDTO;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="vehicle")

public class Vehicle {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long vehicle_id;
	
	private String registration_no;
	private String vehicle_type;
	
//	public Vehicle(VehicleDTO vehicleDTO) {
//		this.vehicle_id=vehicleDTO.getVehicle_id();
//		this.registration_no=vehicleDTO.getRegistration_no();
//		this.vehicle_type=vehicleDTO.getVehicle_type();
//		
//	}

	

}
