package com.capg.chalo.service;

import java.util.List;

import com.capg.chalo.entity.Vehicle;
import com.capg.chalo.exception.VehicleNotFoundException;

public interface VehicleService {
	public Vehicle addVehicle(Vehicle vehicle);
	public Vehicle removeVehicle(Long vehicle_id) throws VehicleNotFoundException;
	public Vehicle getVehicleDetails(Long vehicle_id) throws VehicleNotFoundException;
    public Vehicle updateVehicle(Long vehicle_id ) throws VehicleNotFoundException;
    public List<Vehicle> getAllVehicleDetails();
    void deleteAll();
}
