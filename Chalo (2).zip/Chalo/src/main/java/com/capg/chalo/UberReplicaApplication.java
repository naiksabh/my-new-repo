package com.capg.chalo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UberReplicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UberReplicaApplication.class, args);
	}

}
